# Quy đổi toạ độ UAV, camera, LiDAR, vật, tay gắp về một hệ thế giới

Kế hoạch bản 2, 2026-11-18. Viết lại sau khi đọc kỹ thiết kế nhìn từ trên xuống của `his_perception_uav`.

- Perception: `2026.1/his_perception_uav` (clone `angelinaanh/his_perception_uav`; C++, NCNN, Pi 4; repo lồng riêng, không commit vào repo chính).
- Firmware bay: **PX4**.
- Tay gắp và RL: `2026.1/rl_arm5` (xem `INTEGRATION_RL.md`, `README_PI5.md` §10).

## 0. Thiết kế của repo perception, và hệ quả cho bài toán toạ độ

Thiết kế (README, `apps/live_app.cpp`):
- UAV **hover**; camera **nhìn thẳng xuống**.
- Một phiên: s1 → s3 chọn **1 vật gần tâm ảnh** → **khoá** `p_W = T_WC(t0)·p_C(t0)`.
- Bám tối đa 3 s (tư thế FC + optical flow ảnh + Kalman, s2 theo nhịp LiDAR) → s4 cuối. Kết quả: tâm mặt trên, 3 trục, W, L, yaw và `p_W` (mm, NED của EKF).
- Lấy nét khoá ở 0,8 m, nên đo ở độ cao khoảng 0,6–1,0 m.

Hệ quả:
1. **Vật chỉ được đo khi nó ở dưới camera.** Lúc vật nằm trong vùng gắp, nó ở trước camera 18 cm và thấp hơn 18 cm (lệch 45° so với trục quang). Nửa góc nhìn dọc là 33°, nên camera không thấy vật nữa. Đây là đúng thiết kế, không phải lỗi.
2. Vì vậy, **toạ độ vật cho tay phải đi qua W**: `p_A(t) = T_AB · T_BW(t) · p_W,vật`. Không đi thẳng từ camera được như bản 1 viết.
   - `p_W,vật` cố định, lấy từ lần khoá cuối.
   - `T_BW(t)` lấy từ EKF, liên tục.
   - Sai số khi gắp = sai số đo của perception + **độ trôi EKF từ lúc khoá tới lúc gắp** + sai số `T_BA`.
3. **EKF phải có vị trí ngang thật** (optical flow MTF-01) và độ cao ổn định. Hiện MTF-01 hỏng, nên chưa có `p_W` dùng được cho bay và gắp. Phần quy đổi, calib và kiểm tĩnh vẫn làm được.
4. Cách giảm độ trôi: **đo lại `p_W` trong lúc tiếp cận**, chừng nào vật còn trong ảnh (mục 4). Chỉ đoạn cuối, khoảng 10 cm, là đi "mù".

---

## 1. Repo perception đã có gì

| Thành phần | Trạng thái | Ở đâu | Ghi chú |
|---|---|---|---|
| K camera (IMX708 1920×1080, lật 180°) | ✅ v2, RMS 0,28 px | `configs/calib/K_1920x1080.yaml` | file 960×540 = bản thu nhỏ 2 lần |
| LiDAR → camera `T_CL` | ✅ v5, RMS 6,5 mm | `configs/calib/T_CL.yaml` | chỉ đúng nếu giá camera + LiDAR không bị tháo lắp |
| Camera → thân `T_BC` | ⚠️ v0 danh nghĩa, **t = 0** | `configs/calib/T_BC.yaml` | có số đo thước (mục 9); R chưa calib |
| Tay → thân `T_BA` | ❌ chưa có | — | có bản nháp (mục 9) |
| `T_WB(t)` | ✅ `ATTITUDE` (nội suy) + `LOCAL_POSITION_NED` + rangefinder | `src/tracking/world_pose.cpp` | **z bị thay bằng rangefinder, chưa trừ offset cảm biến** (mục 3) |
| Đồng bộ thời gian | ✅ có; `latency_ms` = 0, chưa đo | `mavlink.cpp` | |
| Vật trong W | ✅ `p_W_lock_mm`, `p_W_mm` (s4) | `result.json`, `fc_events.jsonl`, TCP 8100 | **chưa có kênh thời gian thực cho bộ điều khiển** |
| Gửi setpoint cho PX4 | ✅ có trong `uav_controller` (MAVSDK, `fly x y`, giữ D và yaw) | `2026.1/uav_controller/pi/` | thiếu lệnh tới vật (mục 9b) |
| Giải mã chế độ bay | ❌ theo ArduCopter (`50593792 ?`) | `mavlink.cpp`, `start.modes` | sửa trước khi bật `require_hover` |
| Độ cao từ FC | ❌ không có `DISTANCE_SENSOR` vì MTF-01 hỏng | | sửa xong thì kiểm lại; nếu vẫn thiếu: `mavlink stream -d <cổng TELEM1> -s DISTANCE_SENSOR -r 20` |

---

## 2. Các hệ toạ độ

Quy ước: `p_X = R_XY·p_Y + t_XY`, đơn vị m (repo dùng mm ở `p_W`). Chỉ dùng NED/FRD, không trộn ENU/FLU.

| Hệ | Gốc | Trục | Nguồn |
|---|---|---|---|
| **W** | **điểm cất cánh**: mặt đất ngay dưới Pixhawk lúc `takeoff` (mục 2b) | NED, giữ trục của EKF | EKF − `launch_ned` |
| **B** | tâm Pixhawk (coi là IMU; `EKF2_IMU_POS_*` = 0) | FRD; **+x = mũi tên Pixhawk = phía camera + LD06** (`SENS_BOARD_ROT` = 0, đã kiểm) | `ATTITUDE`, `LOCAL_POSITION_NED` |
| **C** | tâm quang IMX708 | OpenCV trên ảnh đã lật 180°; z nhìn xuống | `T_BC` |
| **L** | tâm quay LD06 | x trước, y trái, z lên | `T_CL` ✅ |
| **A** | gốc ảo của RL, nằm dưới J1 0,5808 m; J1 ở (0; −0,0108; 0,5808) | x phải, y trước (hướng tay vươn khi gắp), z lên; tay thòng xuống như lúc train | `T_BA` |
| **O** | tâm mặt trên vật (s4) | pháp tuyến n, trục dài theo yaw | s4 |

---

## 2b. Hệ thế giới W: chốt theo yêu cầu người dùng (2026-11-19)

Yêu cầu: UAV, camera, tay và mọi vật cùng một hệ W. **Gốc W = nơi UAV bắt đầu bay.** Vật đứng yên thì có toạ độ W **không đổi**, dù UAV nhìn thấy nó từ chỗ nào.

Cách dựng:
- `p_W = p_EKF − o`, với `o` = vị trí EKF của Pixhawk lúc `takeoff` (`launch_ned`, console đã ghi sẵn) + (0; 0; 0,25 m). Gốc rơi xuống mặt đất ngay dưới Pixhawk, nên sàn nơi cất cánh có z_W = 0.
- Gốc EKF của PX4 nằm ở chỗ EKF khởi động, không phải chỗ cất cánh: bật nguồn xong mà khiêng UAV đi thì hai chỗ khác nhau. Vì vậy phải trừ `o`.
- Trục: giữ NED của EKF (x Bắc theo la bàn). Nếu muốn x = mũi UAV lúc cất cánh thì xoay thêm Rz(−ψ0). Đề xuất: giữ NED, để khớp setpoint PX4 không phải đổi.

Mỗi thành phần trong W:

| Thành phần | Trong W | Đổi theo thời gian |
|---|---|---|
| UAV | `T_WB(t)` = EKF − `o` | có |
| Camera | `T_WC(t) = T_WB(t)·T_BC` | có |
| LiDAR | `T_WL(t) = T_WC(t)·T_CL` | có |
| Đế tay | `T_WA(t) = T_WB(t)·T_BA` | có |
| Đầu gắp | `T_WA(t)·FK(q)` | có |
| **Vật** | `p_W`, yaw, W, L, H | **không** (vật đứng yên) |

**Bản đồ vật (S9, mới).** Mỗi lần perception đo xong (s4), đổi vật sang W rồi so với bản đồ:
- cách một vật đã có dưới ngưỡng (ví dụ 10 cm, cùng loại) → cùng vật: cập nhật trung bình có trọng số, tăng số lần thấy;
- không trùng → thêm vật mới với id mới.

Lưu file JSON trên Pi (id, loại, `p_W`, yaw, kích thước, độ lệch chuẩn, số lần thấy, lần thấy cuối). Lệnh `approach <id>` đọc từ bản đồ này.

**Giới hạn vật lý:** "không đổi" chỉ đúng tới mức EKF không trôi. Với optical flow, vị trí ngang trôi khoảng vài cm mỗi mét bay (cần đo ở V2). Vật thấy lại sau một quãng bay sẽ lệch đúng bằng độ trôi đó. Cách theo dõi:
- dùng chính bản đồ: độ lệch giữa các lần thấy cùng một vật chính là thước đo độ trôi;
- trước khi gắp, luôn **đo lại** vật khi đã tới gần.

## 3. Chuỗi biến đổi

```
 p_L ─T_CL─► p_C ─T_BC─► p_B ─T_WB(t0)─► p_W,vật   (khoá / đo lại khi vật còn trong ảnh)
                                            │
                       T_AB · T_BW(t), t = bây giờ (EKF, 30–50 Hz)
                                            ▼
                                           p_A ──► UDP 5555 ──► SAC / IK
```

- **Đo:** `p_W = R_WB(t)·(R_BC·p_C + t_BC) + t_WB(t)`, với t là thời điểm chụp (hoặc thời điểm của điểm LiDAR).
- **Gắp:** `p_A(t) = R_AB·(R_WB(t)ᵀ·(p_W − t_WB(t))) + t_AB`.
  - Gửi liên tục, nên dao động khi hover hiện ra như **vật trôi chậm** trong A. Stage B+ đã được train với vật trôi 0,8–1,4 cm/s.
- **Tâm vật cho RL:** RL nhận **tâm trụ**, còn s4 cho **tâm mặt trên**.
  - `p_tâm,W = p_mặt trên,W + (H/2)·e_z,W`, với H là chiều cao vật (z xuống).
  - H đo được bằng khoảng cách tới sàn trừ khoảng cách tới mặt trên. Nếu biết trước loại vật thì dùng giá trị cố định trong config.
- **Hướng vật:** `n_W = R_WB·R_BC·n_C`. Trục dài cũng quy về W theo cách này để chọn yaw UAV (mục 4).
- **Độ cao trong `camera_pose()` cần sửa:**
  - Hiện code dùng `z_WB = −range·cos(roll)·cos(pitch)`, coi rangefinder nằm ngay tâm B.
  - MTF-01 nằm ở r = (−0,12; −0,03; +0,09) trong B. Công thức đúng (sàn phẳng): `z_WB = −range·(R_WB e_z)_z − (R_WB r)_z`. Khi UAV ngang, sai 9 cm.
  - Sai số này triệt tiêu khi lúc đo và lúc gắp cùng dùng một công thức. Nhưng nó **làm sai khi trộn với z của EKF** để gửi setpoint.
- **Một nguồn độ cao duy nhất (chốt, khác bản 1):**
  - Đặt `EKF2_HGT_REF` = 2 (range) và `EKF2_RNG_CTRL` bật.
  - Sau đó **dùng z của `LOCAL_POSITION_NED` cho cả đo, gắp và setpoint**. Tắt việc thay z trong `camera_pose()`, hoặc chỉ dùng rangefinder để kiểm chéo.
  - Mặt không phẳng (bối cảnh đích): rangefinder đọc nhảy khi bay qua vật. PX4 có bộ kiểm "terrain"; theo dõi khi bay thử.
- **`distance.camera_offset_m`** (D camera → sàn cho s3) = **−0,02** theo số đo mới (camera thấp hơn MTF-01 2 cm). Config hiện là −0,05 (đo 2026-11-16), cùng dấu; nên đo lại một lần rồi chốt.

---

## 4. Tiếp cận: từ `p_W,vật` tới điểm đặt cho PX4

Điểm đích trong B (tâm vùng gắp, cố định sau khi có `T_BA`):
`p_B* = T_BA·p_A*`, với `p_A*` = (0; 0,295; 0,40) → **`p_B*` ≈ (0,311; −0,03; 0,291)**.

Yaw đích ψ*:
- Vật trụ: giữ yaw hiện tại, hoặc quay sao cho vật nằm thẳng trước tay (θ = 0).
- Vật dài (W < L): tay 4 khớp **không có xoay cổ tay**, nên mặt phẳng kẹp cố định theo hướng vươn. Chọn ψ* sao cho trục dài của vật song song với hướng vươn +x_B; lấy theo mod 180°, gần yaw hiện tại nhất.
- Kiểm lại hướng ngàm kẹp trên tay thật trước khi chốt.

Vị trí UAV đích: `t_WB* = p_W,tâm vật − R_z(ψ*)·p_B*`, với roll = pitch = 0.

Gửi `SET_POSITION_TARGET_LOCAL_NED` (`MAV_FRAME_LOCAL_NED`, vị trí + yaw) ở 20–30 Hz. PX4: bật OFFBOARD sau khi đã gửi setpoint ≥ 2 Hz.

**Ba nấc:**
1. **ĐO:** hover ở 0,6–1,0 m (ống kính tới mặt vật), vật gần tâm ảnh → perception khoá + s4 → `p_W`, yaw, W, L, H.
2. **TIẾP CẬN CHÉO:** đi dần về `t_WB*` theo đường chéo, giữ vật trong ảnh (ở nửa trên ảnh, phía mũi) càng lâu càng tốt.
   - Vật còn thấy được khi độ sâu ống kính → vật > 0,18 / tan 33° ≈ **0,28 m** (vật lệch trước camera 18 cm).
   - Trong đoạn này, tracker bám bằng ROI dự đoán từ tư thế (đã có sẵn) và **cập nhật `p_W`** sau mỗi lần s2 + s4.
   - Cần đổi repo: cho phép bám vật xa tâm ảnh và chạy quá 3 s.
3. **BÀN GIAO:** đoạn cuối (khoảng 10 cm hạ) đi theo `p_W` cuối + EKF. Điều kiện:
   - vật IN vùng gắp theo `p_A(t)`, N khung liền;
   - vận tốc ≤ 0,1 m/s;
   - tuổi tư thế < 0,2 s.

   Sau đó chạy `sac_grasp_loop.py` / `ik_grasp_loop.py`, nhận `p_A(t)` qua UDP 5555. UAV giữ setpoint trong lúc gắp.

**Kiểm khả thi độ cao (cần người dùng xem):**
- Lúc gắp, tâm vật thấp hơn Pixhawk 0,25–0,33 m (theo vùng z 0,36–0,44 của RL); khi UAV đậu, Pixhawk cách sàn 0,25 m.
- Người dùng (2026-11-18): **trước mắt vẫn khả thi**, với tư thế gắp tay duỗi thẳng; RL đang được train tiếp cho tình huống này. Khi có vùng gắp mới thì cập nhật `p_A*` và `p_B*`.

---

## 5. Hiệu chuẩn

| # | Việc | Cách làm | Đạt khi | Trạng thái |
|---|---|---|---|---|
| K0 | Chốt cơ khí | camera + LD06 + tay khoá vít ở vị trí cuối, chụp ảnh lưu | — | chờ người dùng xác nhận giá cuối |
| K1 | Kiểm lại K, `T_CL` sau khi lắp | `aruco_check` của repo ở 0,5–1,0 m | lệch ≤ 2 cm | chưa |
| K2 | **`R_BC`** | bảng ArUco cố định trên sàn; cầm UAV nghiêng / xoay ±20–30°, khoảng 20 tư thế; mỗi tư thế lấy cặp (`ATTITUDE`, PnP bảng); giải phần quay hand-eye. Kiểm bằng trọng lực: bảng nằm ngang thì pháp tuyến trong W phải thẳng đứng | phần dư ≤ 0,5° | chưa; **không cần EKF vị trí** |
| K3 | `t_BC` | thước | ≤ 5 mm | ✅ đo thước xong (mục 9): (0,130; −0,03; 0,11) m; chưa ghi vào `T_BC.yaml` |
| K4 | **`T_BA`** = `T_BC·T_CA` | ArUco nhỏ trên ngàm; khoảng 10 tư thế (FK `assarm_common`) → cặp (p_A FK, p_C đo) → Kabsch. Gồm cả sai số vòng hở / võng servo | phần dư ≤ 1 cm | chưa; nháp từ thước ở mục 9 |
| K5 | Độ trễ FC ↔ camera | xoay nhanh trước bảng; tương quan chéo góc PnP với `ATTITUDE` | ± 5 ms → `latency_ms` | chưa |
| K6 | Nguồn độ cao + offset cảm biến | `EKF2_HGT_REF` = 2, `EKF2_RNG_CTRL`; `EKF2_OF_POS_*` = `EKF2_RNG_POS_*` = (−0,12; −0,03; 0,09) | z đứng yên trôi ≤ 1 cm / 30 s | chờ MTF-01 |

Lưu theo cách của repo: `configs/calib/T_BC.yaml` (tăng `version`), file mới `T_BA.yaml`; bản cũ đưa vào `_backup/`.

Lưu ý K4: camera nhìn xuống không thấy ngàm ở vùng gắp (45°). Có hai cách:
- chọn các tư thế FK nằm trong ảnh (tay vươn xa / thấp hơn), rồi suy ra `T_BA`;
- hoặc dùng `T_BA` từ thước + FK, rồi kiểm V4 bằng thước.

---

## 6. Kiểm chứng

| # | Bài thử | Đạt khi | Cần MTF-01 |
|---|---|---|---|
| V1 | cầm xoay roll / pitch / yaw ±20° trên bảng ArUco cố định | độ lệch chuẩn `p_W` tâm bảng ≤ 1–2 cm | không (chỉ dùng góc, UAV đứng một chỗ) |
| V2 | cầm dời 50 cm theo thước | `p_W` bảng trôi ≤ 3 cm | **có** |
| V3 | hover 30 s trên vật | `p_W` lệch ≤ 3–5 cm | có |
| V4 | tay tới 5 điểm FK, đo bằng thước trong B | lệch ≤ 1 cm | không |
| V5 | trên giá: vật đặt theo thước trong vùng gắp, `p_A` từ `p_W` (UAV đứng yên) | ≤ 1 cm; IN/OUT 12/12 | không (giữ vị trí giả = 0) |
| V6 | phát lại log (S6): đo → tiếp cận → bàn giao | `t_WB*` và IN/OUT đúng | không |
| V7 | bay: đo → tiếp cận chéo → hover trong vùng | vật IN ≥ 5 s | có |

---

## 7. Phần mềm

| # | Việc | Ở đâu |
|---|---|---|
| S1 | Kênh xuất thời gian thực từ perception: UDP JSON mỗi lần s4 (t chụp, `p_W` mặt trên, n, yaw, W, L, H, σ, cờ) | `his_perception_uav` (C++, cạnh `remote_view`); tôn trọng `CPP_RULES.md` |
| S2 | ✅ Python xong 2026-11-18 (`scripts/frames.py --selftest` ĐẠT; còn phần C++). Thư viện frames dùng chung + test: `T_WB` từ MAVLink, `T_BC`, `T_CL`, `T_BA`, `p_A(t)` từ `p_W`, công thức z rangefinder có offset | `CoVip/scripts/frames.py`; C++: sửa `world_pose.cpp` (offset rangefinder, tuỳ chọn dùng z EKF) |
| S3 | Calib K2, K4, K5 | `CoVip/scripts/calib_uav_*.py`, đọc log `runs/` |
| S4 | Điều khiển tiếp cận: ĐO → TIẾP CẬN CHÉO → BÀN GIAO; giới hạn tốc độ, vùng an toàn, huỷ khi mất vật | **đọc `~/uav/controller` (`console.py`) trước**; MAVLink qua endpoint router riêng |
| S5 | Cầu nối tay: đọc `LOCAL_POSITION_NED` + `ATTITUDE` (endpoint router riêng) + `p_W` (S1) → `p_A(t)` → UDP 5555 + trạng thái vùng (5557) | `CoVip/scripts/uav_arm_bridge.py`, dùng lại `assarm_link.py` |
| S6 | Phát lại log thật + tư thế giả | máy tính |
| S7 | Giải mã chế độ PX4 (`custom_mode`: main mode, sub mode) | `his_perception_uav` `mavlink.cpp`, config `start.modes` |
| S9 | **Bản đồ vật trong W** (mục 2b): gộp các lần thấy, id cố định, file JSON; `approach <id>` | `CoVip/scripts/object_map.py` (Python, đọc `result.json`) |
| S8 | Bám vật xa tâm, đo lại `p_W` trong lúc tiếp cận (nấc 2) | `his_perception_uav` `locked_tracker` / `live_app` |

---

## 8. Thứ tự làm

1. **Ngay, không cần MTF-01:**
   - K2 + V1 (R_BC);
   - S2, S3 trên laptop.
2. Đọc `controller` (`console.py`, chép về `2026.1/uav_controller/`, repo lồng không commit) → chốt S4, S5.
3. V4, V5 trên giá (tay + `p_A` từ `p_W` khi UAV đứng yên).
4. **Sửa / thay MTF-01** → bật luồng `DISTANCE_SENSOR`, K6 → V2.
5. S1, S8 (repo perception), S6 → V3 → V7 bay có dây an toàn → gắp đầu–cuối.

---

## 9. Số đo của người dùng và bản nháp T_BC, T_BA

Số đo (2026-11-18):
- `SENS_BOARD_ROT` = No rotation; mũi tên Pixhawk chỉ về camera + LD06.
- Tâm quang camera ↔ J1: 12,5 cm theo x (camera ở trước). MTF-01 ↔ J1: 12,5 cm phía sau.
- Mặt dưới MTF-01 cao 16 cm; giữa hộp Pixhawk cao 25 cm. Pixhawk cách MTF-01 12 cm, lệch ngang 3 cm.
- Camera nhìn thẳng xuống; camera ≈ cùng cao J1; J1 ↔ MTF-01 lệch 2 cm.
- Tay thòng xuống (như lúc train); khi gắp vươn về phía camera.

**Giả định cần xác nhận:**
- (a) ✅ J1, camera cao **14 cm** (thấp hơn MTF-01 2 cm), người dùng xác nhận.
- (b) ✅ tâm Pixhawk dời 3 cm sang trái thì về đường tâm UAV; từ đó đo 12 cm ngược mũi tên (về đuôi) tới MTF-01.
- (c) ✅ Pixhawk nằm **bên phải** đường camera–J1–MTF-01 3 cm, tức d = +0,03: các điểm trên đường tâm có y_B = −0,03.

Trong B (z_B = 0,25 − độ cao):

| Điểm | x_B | y_B | z_B |
|---|---|---|---|
| J1 | +0,005 | −0,03 | +0,11 |
| Camera | +0,130 | −0,03 | +0,11 |
| MTF-01 | −0,120 | −0,03 | +0,09 |
| tâm vùng gắp L0 | +0,311 | −0,03 | +0,291 |

Phép biến đổi:
- `R_BC` = [[0,−1,0],[1,0,0],[0,0,1]] (danh nghĩa, chờ K2 và bài xem ảnh), `t_BC` = (0,130; −0,03; 0,11).
- `R_BA` = [[0,1,0],[1,0,0],[0,0,−1]] (det +1), `t_BA` = (0,0158; −0,03; 0,6908).

**Lịch sử kiểm Pixhawk → Pi (2026-11-18):**
- Router PX4 → `uavp_fc_check`: 0 lỗi CRC, `ATTITUDE` 100/s, `LOCAL_POSITION_NED` 30/s.
- Không có `DISTANCE_SENSOR`.
- z trôi khoảng 1 cm/s (áp kế).
- **MTF-01 hỏng.**

## 9b. Repo điều khiển `uav_controller` (chép từ Pi `~/uav/controller` về `2026.1/uav_controller/`, 2026-11-18; repo lồng, không commit; bỏ `.native/` MAVSDK)

**Đã có:**
- `pi/console.py` + `pi/offboard_control.py`: MAVSDK Python, OFFBOARD bằng `set_position_ned` (N, E, D, yaw), MAVSDK tự lặp lại 20 Hz.
- Lệnh `arm`, `takeoff` (lên `--height` so với điểm cất cánh, độ cao **cố định cả chuyến**), `fly x y` (N/E tuyệt đối, **giữ nguyên độ cao và yaw**), `land`, `disarm`.
- Tới đích: `ArrivalMonitor` (dung sai mặc định xy 0,5 m, z 0,3 m, yaw 10°, đứng 2 s) → chuyển PX4 HOLD.
- `--position-source flow` + `site_origin.json` (gốc EKF khi không có GPS).
- `perception_process.py`: chạy `uavp_real_time` làm tiến trình con.
  - Lệnh `perception` chỉ nhận khi đang HOLD (hoặc `--perception-bench`: chưa arm, trên đất).
  - Gửi START/STOP bằng `COMMAND_LONG` 31010.
  - Đọc log để biết kết quả: dòng `Ket qua: <thư mục>` → `last_result` (thư mục `runs/` có `result.json` với `p_W_mm`).
- Router (`config/mavlink-router.conf`): Pixhawk **TELEM1** (`MAV_0_CONFIG` = 101; ghi chú: chân TX của TELEM2 hỏng) → console 14540, perception 14551, QGC 14550.
- `params/quad_3s_mtf01_indoor.params`: MTF-01 nối MAVLink vào **TELEM3** 115200; `EKF2_HGT_REF` = 2, `EKF2_RNG_CTRL` = 2, `EKF2_OF_CTRL` = 1, tốc độ tối đa 0,5 m/s.
  - **Chưa đặt `EKF2_OF_POS_*` / `EKF2_RNG_POS_*`**: dùng (−0,12; −0,03; 0,09).
  - PX4 tính offset so với **trọng tâm**. Nếu Pixhawk lệch trọng tâm thì đặt thêm `EKF2_IMU_POS_*`.
  - z trôi theo áp kế lúc kiểm là do MTF-01 hỏng, không phải do sai tham số.

**Còn thiếu cho bài toán gắp:**
1. **Perception → điều khiển:** kết quả chỉ nằm trong `result.json` trên Pi, console chỉ in đường dẫn.
   - Bản đầu **không cần sửa C++ (S1)**: console đọc `result.json` của `last_result`.
2. **Bay tới vật:** cần lệnh mới (ví dụ `approach`): đọc `p_W` → `frames.uav_setpoint` → đặt N, E, **D và yaw**. Hiện `fly` không đổi được D và yaw.
3. **Dung sai 0,5 m quá thô** cho gắp (cần khoảng 2–3 cm). Cần tham số riêng cho pha tiếp cận, tốc độ chậm hơn, có bước hạ độ cao.
4. **Bàn giao cho tay:** khi HOLD trong vùng, chạy cầu nối `p_A(t)` (S5) + `ik_grasp_loop.py` / SAC.
   - Cầu nối đọc tư thế qua một endpoint router mới, ví dụ `127.0.0.1:14560`. Không dùng chung 14540 với console.
5. **Hệ z không khớp:**
   - `p_W.z` của perception bị thay bằng `−range·cos·cos` (sàn = 0); z của console là z EKF (gốc ở điểm khởi tạo).
   - Sửa không cần code: chạy perception với `--perception-set sources.mavlink.use_rangefinder=false` → `p_W.z` lấy từ `LOCAL_POSITION_NED`.
   - `use_rangefinder` chỉ ảnh hưởng `camera_pose()`. D cho s3 vẫn lấy độ cao FC riêng (`start_gate`).
6. Console chỉ cho bắt đầu quét khi HOLD. Như vậy đã hợp với nấc ĐO, nhưng nấc TIẾP CẬN CHÉO (đo lại khi đang bay) cần thêm.

Kế hoạch S4 sửa theo: **mở rộng `console.py`** (lệnh `approach`, `grasp`), không viết bộ điều khiển mới. Cần thống nhất với người giữ repo controller.

### B1 (2026-11-20): Pixhawk → Pi, UAV đứng yên trên giá

ĐẠT, 0 lỗi CRC.
- **Đã có `DISTANCE_SENSOR`** (10/s, đọc 0,64–0,66 m, tức Pixhawk cao khoảng 0,74 m).
- z của EKF dao động −0,687…−0,713 m nhưng **không trôi** (trước đây trôi khoảng 1 cm/s). Nghĩa là độ cao EKF đã lấy từ rangefinder.
- x, y đứng yên ±2 mm. Bài này chưa chứng minh được flow chạy, vì UAV đứng yên và repo không đọc `OPTICAL_FLOW_RAD`.
- Kiểm thêm trong MAVLink Console: `listener sensor_optical_flow`, `listener estimator_status_flags` (cờ `cs_opt_flow`, `cs_rng_hgt`).

### Kiểm flow bằng cách đẩy UAV (2026-11-20), giữ độ cao, không xoay

| Kiểm | Kết quả | Đánh giá |
|---|---|---|
| Hướng | Đẩy 50 cm về phía mũi: Δ = (−0,408; +0,146) m, hướng 160°, yaw 156–158° | ✅ đúng hướng, `SENS_FLOW_ROT` đúng |
| Độ dài | 0,435 m so với 0,50 m thật | ⚠️ ngắn 13%. Làm lại 2 lần; nếu vẫn vậy thì chỉnh hệ số scale của flow (khoảng 1,15) |
| Quay về vạch xuất phát | lệch < 1 cm | ✅ |
| Yaw sau khi xoay 360° | 159,9° → 158,4°, lệch 1,4° | ✅ la bàn không trôi. Lần lệch 14° trước là do đặt UAV lại lệch hướng |
| Vị trí sau khi xoay tại chỗ | lệch 7,6 cm | ⚠️ chưa đặt `EKF2_OF_POS_*` / `EKF2_RNG_POS_*` (MTF-01 cách Pixhawk 12 cm), và có lúc bị nhấc lên (range 0,28 m) |

### Đặt offset MTF-01 + B2 (2026-11-20)

- `EKF2_OF_POS_*` = `EKF2_RNG_POS_*` = (−0,12; −0,03; 0,09) đã đặt. `OF_POS_X` lúc đầu nhập nhầm +0,12, đã sửa, đã reboot.
- Bài xoay tại chỗ để kiểm offset **hoãn sang lúc hover (V3)**: UAV kê cao vì tay, nên khi xoay, mép giá kê lọt vào tầm nhìn MTF-01 (range tụt 0,17–0,19 m).
- Đứng yên 10 s sau reboot: x, y ±3 mm; z ±1,3 cm. ✅
- **B2 ✅:**
  - chúc phía camera xuống → pitch −11…−15°;
  - nghiêng phải → roll +12…+27°;
  - yaw ổn định.
  - Khi roll 26°, range 0,72 m ≈ 0,65 / cos 26°. Rangefinder và tư thế khớp nhau; z của EKF vẫn giữ khoảng −0,70.
  - Trả về ngang thì x, y về trong 1,5 cm.

### B4 (2026-11-20): đo lại thước

✅ Cả 8 số đo khớp bản cũ, sai không quá 0,5 cm. `T_BC` (t), `T_BA` nháp và offset MTF-01 giữ nguyên.

**Camera:** cáp CSI hỏng (I2C vẫn thấy imx708, nhưng không có khung; sau khi cắm lại thì mất hẳn camera). Đang chờ mua cáp. B3, B5, B6, K2 tạm dừng.

### Camera + ArUco trong W (2026-11-20, camera_check, không LiDAR)

- ArUco 36,5 mm trên vật cao 61 mm, đặt dưới camera. Thước: ống kính → ArUco = 540 mm, **khớp `p_C` z = 540**; cạnh 36,5 đúng.
- `p_B` = (126, −29, 650). Thước (từ MTF-01: trước 270, trái 10) → (150, −40). Lệch 24 / 11 mm: chờ A2 (MTF → camera) để tách `t_BC` hay `R_BC`.
- Pixhawk báo pitch −1,9°, roll 1,0° khi UAV phẳng → cần **Level Horizon**.
- MTF-01 đọc 0,65 m, thật ≈ 0,62 (dư ~3 cm) → `--fc-height-m 0.711` (thêm vào camera_check).
- EKF đứng yên vẫn trôi ~35 mm và yaw 2,3° trong ~2 phút → giới hạn độ đứng yên của vật trong W.

## 11. Kịch bản camera + LiDAR + UAV (2026-11-21, đã có lại LD06)

Chuỗi: `p_L ─T_CL (v5)─► p_C ─T_BC─► p_B ─T_WB(t)─► p_W`.

LD06 trong B (từ `T_CL` v5 + `T_BC` nháp) ≈ **(91, −18, 152) mm**: sau ống kính 39 mm, thấp hơn ống kính 42 mm. Mặt phẳng quét gần vuông góc với x_B, tức là **một "rèm" trái–phải** cắt ngang dưới UAV, cách Pixhawk ~9 cm về phía mũi. Trên ảnh là đường ngang hơi dưới tâm (ở 0,54 m: ~28 mm, ~40 px). Vật chỉ được LiDAR đo khi nằm trên đường này.

| # | Bài | Cách làm | Đạt khi |
|---|---|---|---|
| L0 | Phần cứng | `ls -l /dev/serial/by-id/` có CP2102; không có `console.py` (camera, cổng 8100) | có |
| L1 | Ba nguồn cùng chạy | `uavp_sensor_check --seconds 10 --set sources.mavlink.use_rangefinder=false` | camera ~30 khung/s, LiDAR ~10 vòng/s, ATTITUDE ≥ 10/s |
| L2 | Thước cho LD06 | đo tâm LD06 so với ống kính camera | ≈ 39 mm về phía đuôi, 42 mm thấp hơn, 12 mm sang phải (±5) |
| L3 | Sàn | `overlay.jpg` + `summary.json`: độ sâu điểm sàn dưới tâm ảnh | = thước ống kính → sàn (601 mm) ± 10 mm |
| L4 | `T_CL` còn đúng (K1) | ArUco đặt **trên đường LiDAR**; so độ sâu LiDAR tại marker với ArUco (540) | lệch ≤ 15 mm (lúc hiệu chuẩn TB −19) |
| L5 | T2 có LiDAR | camera_check + LiDAR: `p_W` vật theo ArUco và theo LiDAR | hai cách lệch ≤ 15 mm; khớp thước |
| L6 | T5 | dời giá 20 cm trước / phải, xoay 20° | vật trong W lệch ≤ 3 cm (giới hạn bởi trôi EKF) |

**Kết quả 2026-11-20 (tối), sau Level Horizon (roll/pitch ≈ 0):**
- L1–L4 ✅: LiDAR 10 vòng/s; sàn 590–603 mm (thước 601), mặt hộp 529–537 (thước 540); mép hộp LiDAR khớp ảnh. `T_CL` v5 giữ nguyên. Offset thước (30 mm, 12 mm) khác `T_CL` (38,8; 42) vì z giải ra gộp tâm quang + lệch tầm LD06.
- camera_check có LiDAR (`20261120-195201`): đứng yên 200 s, vật trong W dao động ±3 mm (x, y), ±10 mm (z, nhiễu z EKF). Dời 27–45 cm: vật lệch 9–24 mm ✅. Xoay yaw ±30°: lệch 55–64 mm ❌; đưa về chỗ cũ (`p_B` như đầu) vẫn lệch 62 mm = sai vị trí EKF tích luỹ khi xoay (không phải camera).
- Run `193752`: MTF-01 nhìn phải thanh khung giá khi dời → z EKF nhảy −740 → −110..−450, x/y nhảy tới 40 cm, không hồi lại.
- LD06 đo ngắn: sàn 587 (thước 601), mặt vật − ArUco −25 ± 12 mm.

✅ (2026-11-21) Đã thêm LD06 vào `camera_check` (đọc vòng quét gần nhất, `T_CL` → C, lấy điểm nằm trong ô ArUco, in độ sâu LiDAR và `p_W` theo LiDAR, ghi CSV). LiDAR còn cho độ cao camera → sàn, thay `--fc-height-m` đo tay.

## 10. Câu hỏi còn mở

- Ảnh: tay khi di chuyển hiện trong ảnh (người dùng), nên không cần bài xem cạnh trên ảnh riêng; K2/K4 sẽ chốt `R_BC`. K4 dùng được marker trên ngàm.
- Hướng mặt phẳng kẹp của ngàm so với hướng vươn (để chọn ψ* cho vật dài).
- Ai sửa `his_perception_uav` (S1, S7, S8)?
