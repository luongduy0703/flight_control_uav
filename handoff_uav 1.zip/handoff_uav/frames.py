#!/usr/bin/env python3
"""frames.py — quy đổi toạ độ UAV / camera / LiDAR / vật / tay gắp (xem CoVip/UAV_FRAMES_PLAN.md).

Quy ước: p_X = R_XY @ p_Y + t_XY, đơn vị m (repo his_perception_uav dùng mm ở p_W: nhớ chia 1000).
  W  NED của EKF PX4          B  FRD thân, gốc tâm Pixhawk (IMU), +x = mũi tên Pixhawk = phía camera
  C  OpenCV, ảnh đã lật 180°   L  LD06 (x trước, y trái, z lên)
  A  hệ RL của tay: x phải, y trước (hướng vươn khi gắp), z lên; J1 ở (0; -0.0108; 0.5808)

Chuỗi chính:
  đo:   p_W = R_WB(t) (R_BC p_C + t_BC) + t_WB(t)
  gắp:  p_A(t) = R_AB (R_WB(t)^T (p_W - t_WB(t))) + t_AB
  đích: t_WB* = p_W,tâm vật - Rz(psi*) p_B*,  p_B* = T_BA p_A*

Chạy `python3 frames.py --selftest` để kiểm công thức.
"""
from __future__ import annotations

import argparse
import math
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

# --- Bản nháp từ thước (UAV_FRAMES_PLAN.md mục 9, 2026-11-18). K2/K4 sẽ thay. ---
R_BC_NOMINAL = np.array([[0.0, -1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
T_BC_DRAFT = np.array([0.130, -0.030, 0.110])
R_BA_DRAFT = np.array([[0.0, 1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, -1.0]])
J1_A = np.array([0.0, -0.0108, 0.5808])
J1_B_DRAFT = np.array([0.005, -0.030, 0.110])
T_BA_DRAFT = J1_B_DRAFT - R_BA_DRAFT @ J1_A
R_RNG_B_DRAFT = np.array([-0.120, -0.030, 0.090])  # MTF-01 (flow + đo cao) trong B
P_A_STAR = np.array([0.0, 0.295, 0.40])  # tâm vùng gắp mức 0 (assarm_common/config.py SPAWN_LEVELS)


@dataclass
class Rigid:
    """Phép biến đổi cứng: p_to = R @ p_from + t."""
    R: np.ndarray = field(default_factory=lambda: np.eye(3))
    t: np.ndarray = field(default_factory=lambda: np.zeros(3))

    def __matmul__(self, other):
        if isinstance(other, Rigid):
            return Rigid(self.R @ other.R, self.R @ other.t + self.t)
        p = np.asarray(other, dtype=float)
        return (self.R @ p.T).T + self.t  # 1 điểm (3,) hoặc nhiều điểm (N, 3)

    def inv(self) -> "Rigid":
        return Rigid(self.R.T, -self.R.T @ self.t)

    def rotate(self, v):
        """Chỉ quay (véc-tơ hướng: pháp tuyến, trục)."""
        return (self.R @ np.asarray(v, dtype=float).T).T


def rot_x(a): c, s = math.cos(a), math.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def rot_y(a): c, s = math.cos(a), math.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def rot_z(a): c, s = math.cos(a), math.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def rot_ned_from_body(roll, pitch, yaw):
    """R_WB từ ATTITUDE (rad), ZYX như MAVLink; khớp rotation_ned_from_body() trong world_pose.cpp."""
    return rot_z(yaw) @ rot_y(pitch) @ rot_x(roll)


def T_WB(roll, pitch, yaw, pos_ned) -> Rigid:
    """Tư thế UAV trong W; pos_ned đã ở trong W (dùng T_WB_from_ekf nếu đang có toạ độ EKF thô)."""
    return Rigid(rot_ned_from_body(roll, pitch, yaw), np.asarray(pos_ned, dtype=float))


# --- Gốc W = mặt đất ngay dưới Pixhawk lúc cất cánh (UAV_FRAMES_PLAN.md mục 2b) ---
GROUND_BELOW_FC_M = 0.25  # Pixhawk cao 25 cm khi UAV đứng trên sàn


def world_origin_in_ekf(launch_ned, ground_below_m=GROUND_BELOW_FC_M):
    """Gốc W trong hệ EKF: vị trí EKF của Pixhawk lúc takeoff (console: launch_ned), hạ xuống mặt đất (+z NED)."""
    return np.asarray(launch_ned, dtype=float) + np.array([0.0, 0.0, ground_below_m])


def ekf_to_world(p_ekf, launch_ned, ground_below_m=GROUND_BELOW_FC_M):
    """p_W = p_EKF - o. Trục giữ nguyên NED của EKF, chỉ dời gốc."""
    return np.asarray(p_ekf, dtype=float) - world_origin_in_ekf(launch_ned, ground_below_m)


def T_WB_from_ekf(roll, pitch, yaw, pos_ekf, launch_ned, ground_below_m=GROUND_BELOW_FC_M) -> Rigid:
    """Tư thế UAV trong W từ ATTITUDE + LOCAL_POSITION_NED thô của PX4."""
    return T_WB(roll, pitch, yaw, ekf_to_world(pos_ekf, launch_ned, ground_below_m))


def z_wb_from_range(range_m, R_WB, r_rng_B=R_RNG_B_DRAFT):
    """Độ cao thân (z NED, sàn phẳng ở z = 0) từ rangefinder đặt ở r_rng_B, tia đo theo +z_B.
    Bản trong camera_pose() bỏ qua r_rng_B (coi cảm biến ở tâm B)."""
    return -range_m * R_WB[2, 2] - (R_WB @ r_rng_B)[2]


def load_T_BC(yaml_path: str | Path | None = None) -> Rigid:
    """Đọc configs/calib/T_BC.yaml của his_perception_uav; không có thì dùng bản nháp từ thước."""
    if yaml_path is None:
        return Rigid(R_BC_NOMINAL.copy(), T_BC_DRAFT.copy())
    import yaml
    d = yaml.safe_load(Path(yaml_path).read_text())
    return Rigid(np.array(d["R_BC"], dtype=float), np.array(d["t_BC_m"], dtype=float))


def load_T_BA(yaml_path: str | Path | None = None) -> Rigid:
    if yaml_path is None:
        return Rigid(R_BA_DRAFT.copy(), T_BA_DRAFT.copy())
    import yaml
    d = yaml.safe_load(Path(yaml_path).read_text())
    return Rigid(np.array(d["R_BA"], dtype=float), np.array(d["t_BA_m"], dtype=float))


def object_centre_W(p_top_W, height_m):
    """s4 cho tâm MẶT TRÊN; RL cần TÂM vật: hạ H/2 theo trọng lực (+z NED)."""
    return np.asarray(p_top_W, dtype=float) + np.array([0.0, 0.0, 0.5 * height_m])


def object_in_arm(p_W, T_wb: Rigid, T_ba: Rigid):
    """p_A(t) = T_AB T_BW(t) p_W — gửi cho tracker RL/IK (UDP 5555) mỗi lần có tư thế mới."""
    return T_ba.inv() @ (T_wb.inv() @ p_W)


def wrap_pi(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def yaw_for_long_object(axis_yaw_W, current_yaw):
    """Tay không xoay cổ tay: chọn yaw UAV sao cho trục dài vật song song +x_B (mod 180°), gần yaw hiện tại nhất."""
    a = wrap_pi(axis_yaw_W)
    b = wrap_pi(axis_yaw_W + math.pi)
    return a if abs(wrap_pi(a - current_yaw)) <= abs(wrap_pi(b - current_yaw)) else b


def uav_setpoint(p_obj_W, yaw_target, T_ba: Rigid, p_A_star=P_A_STAR):
    """t_WB* sao cho (roll = pitch = 0, yaw = yaw_target) vật nằm đúng p_A_star trong hệ tay."""
    p_B_star = T_ba @ p_A_star
    return np.asarray(p_obj_W, dtype=float) - rot_z(yaw_target) @ p_B_star


def selftest():
    rng = np.random.default_rng(0)
    T_bc, T_ba = load_T_BC(), load_T_BA()
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"  [{'OK ' if cond else 'SAI'}] {name}")

    for R in (R_BC_NOMINAL, R_BA_DRAFT):
        check("ma trận quay trực chuẩn, det = +1", np.allclose(R @ R.T, np.eye(3)) and abs(np.linalg.det(R) - 1) < 1e-12)
    check("J1 của RL rơi đúng J1 đo bằng thước trong B", np.allclose(T_ba @ J1_A, J1_B_DRAFT))
    check("tay vươn (+y_A) = mũi (+x_B), z_A lên = -z_B",
          np.allclose(T_ba.rotate([0, 1, 0]), [1, 0, 0]) and np.allclose(T_ba.rotate([0, 0, 1]), [0, 0, -1]))
    check("camera nhìn xuống: z_C = +z_B; cạnh trên ảnh (-y_C) = mũi",
          np.allclose(T_bc.rotate([0, 0, 1]), [0, 0, 1]) and np.allclose(T_bc.rotate([0, -1, 0]), [1, 0, 0]))
    pB = T_ba @ P_A_STAR
    check(f"tâm vùng gắp trong B = {np.round(pB, 3)} (trước 0,311, dưới 0,291)", np.allclose(pB, [0.3108, -0.03, 0.2908], atol=1e-3))

    # Vòng kín: đo vật -> W -> đặt UAV ở setpoint -> vật về đúng p_A*
    for _ in range(200):
        roll, pitch = rng.uniform(-0.3, 0.3, 2)
        yaw = rng.uniform(-math.pi, math.pi)
        T_wb = T_WB(roll, pitch, yaw, rng.uniform(-3, 3, 3))
        p_C = np.array([*rng.uniform(-0.3, 0.3, 2), rng.uniform(0.4, 1.0)])
        p_W = T_wb @ (T_bc @ p_C)
        psi = yaw_for_long_object(rng.uniform(-math.pi, math.pi), yaw)
        T_wb_star = T_WB(0, 0, psi, uav_setpoint(p_W, psi, T_ba))
        if not np.allclose(object_in_arm(p_W, T_wb_star, T_ba), P_A_STAR, atol=1e-9):
            check("vòng kín setpoint -> p_A*", False)
            break
        if not np.allclose(T_bc.inv() @ (T_wb.inv() @ p_W), p_C, atol=1e-9):
            check("W -> C -> W", False)
            break
    else:
        check("200 tư thế ngẫu nhiên: W↔C khứ hồi, setpoint đưa vật về đúng p_A*", True)

    R = rot_ned_from_body(0, 0, 0)
    check("UAV ngang, range 0,16 m: tâm B ở 0,25 m trên sàn", abs(z_wb_from_range(0.16, R) + 0.25) < 1e-9)
    R = rot_ned_from_body(0.2, -0.15, 1.0)
    z = z_wb_from_range(0.5, R)
    hit = np.array([0, 0, z]) + R @ R_RNG_B_DRAFT + 0.5 * R[:, 2]
    check("nghiêng: điểm tia rangefinder chạm sàn ở z = 0", abs(hit[2]) < 1e-9)
    check("chọn yaw cho vật dài: lệch ≤ 90° so với yaw hiện tại",
          all(abs(wrap_pi(yaw_for_long_object(a, c) - c)) <= math.pi / 2 + 1e-9
              for a, c in rng.uniform(-math.pi, math.pi, (100, 2))))
    check("tâm vật = mặt trên + H/2 xuống", np.allclose(object_centre_W([1, 2, -0.5], 0.08), [1, 2, -0.46]))

    launch = np.array([0.7, -1.2, 0.05])  # gốc EKF khác chỗ cất cánh (bật nguồn rồi khiêng đi)
    check("lúc cất cánh: Pixhawk ở W = (0; 0; -0,25), sàn có z_W = 0",
          np.allclose(ekf_to_world(launch, launch), [0, 0, -0.25]))
    # Ví dụ trong chat 2026-11-19: vật trên sàn ở W (2,3; 1,0; 0) nhìn từ 2 chỗ khác nhau
    p_obj = np.array([2.3, 1.0, 0.0])
    T1 = T_WB_from_ekf(0, 0, 0, launch + [2.0, 1.0, -0.75], launch)   # UAV W (2; 1; -1)
    T2 = T_WB_from_ekf(0, 0, 0, launch + [1.5, 1.2, -0.55], launch)   # UAV W (1,5; 1,2; -0,8)
    pB1, pB2 = T1.inv() @ p_obj, T2.inv() @ p_obj
    check(f"vật trong B đổi theo UAV: {np.round(pB1, 2)} → {np.round(pB2, 2)}",
          np.allclose(pB1, [0.3, 0, 1.0]) and np.allclose(pB2, [0.8, -0.2, 0.8]))
    worst = 0.0
    for _ in range(200):  # vật đứng yên: đo từ tư thế bất kỳ đều ra cùng p_W
        T = T_WB_from_ekf(*rng.uniform(-0.3, 0.3, 2), rng.uniform(-math.pi, math.pi),
                          launch + rng.uniform(-5, 5, 3), launch)
        p_C = T_bc.inv() @ (T.inv() @ p_obj)  # camera thấy vật ở đâu
        worst = max(worst, np.abs(T @ (T_bc @ p_C) - p_obj).max())
    check("vật đứng yên: 200 tư thế UAV ngẫu nhiên đều ra cùng p_W", worst < 1e-9)
    print("ĐẠT" if ok else "CÓ LỖI")
    return ok


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--print", action="store_true", help="in T_BC, T_BA, p_B* hiện dùng")
    a = ap.parse_args()
    if a.print or not a.selftest:
        T_bc, T_ba = load_T_BC(), load_T_BA()
        np.set_printoptions(precision=4, suppress=True)
        print("R_BC =\n", T_bc.R, "\nt_BC =", T_bc.t)
        print("R_BA =\n", T_ba.R, "\nt_BA =", T_ba.t)
        print("p_B* (tâm vùng gắp) =", T_ba @ P_A_STAR)
        print("EKF2_OF_POS / EKF2_RNG_POS =", R_RNG_B_DRAFT)
    if a.selftest:
        raise SystemExit(0 if selftest() else 1)


if __name__ == "__main__":
    main()
