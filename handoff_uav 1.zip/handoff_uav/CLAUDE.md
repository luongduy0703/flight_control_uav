# Quy tắc cho Claude Code: hệ toạ độ chung UAV – camera – LiDAR – tay gắp

Chép thư mục này vào repo làm việc (ví dụ `his_perception_uav/integration/uav_frames/`), rồi thêm vào `CLAUDE.md` của repo đó một dòng: "Hệ toạ độ chung: đọc `integration/uav_frames/CLAUDE.md`".

Giao tiếp với người dùng bằng tiếng Việt.

## Bắt đầu
1. Đọc `README.md`: trạng thái, hệ toạ độ, thứ đã có trên Pi, cách chạy, sai số, việc còn lại.
2. Chạy `python3 frames.py --selftest` và `python3 object_map.py --selftest`: phải ra ĐẠT.
3. Chỉ mở `UAV_FRAMES_PLAN.md` khi cần dẫn xuất hay nhật ký test chi tiết.

## Pi và phần cứng
- Claude **không có mật khẩu SSH** của Pi và không tìm cách lấy. Mọi lệnh ssh / scp / chạy trên Pi do người dùng tự chạy: đưa lệnh đầy đủ, ghi rõ chạy ở terminal nào.
- Không cmake lại trong `~/uav_perception_pi` (CMake của chủ repo đang hỏng). Build riêng ở `~/uav_camera_check/` (`pi_patch/camera_check_build/`).
- Pi dùng chung với người khác: trước khi chạy camera, kiểm không có `console.py` / `uavp_real_time`. Không tắt chương trình của người khác. UAV còn lắp cánh: khi có người chạy `console.py --enable-actuation` thì không cầm UAV.
- Không bật router thứ hai; không mở thẳng UART Pixhawk.

## Quy ước bắt buộc
- `p_X = R_XY·p_Y + t_XY`; tên ghi hệ đích trước: `T_WB`, `R_BC`, `t_BA`. Chỉ NED (W, EKF) và FRD (B); không trộn ENU/FLU.
- W: gốc ở mặt sàn dưới Pixhawk lúc bắt đầu, trục NED của EKF. Vật đứng yên phải có `p_W` không đổi.
- z của `T_WB` lấy từ EKF (`use_rangefinder=false`). Không trộn z rangefinder với x, y EKF.
- Bản đồ vật và cầu nối dùng **hệ EKF**: gốc W triệt tiêu trong `p_A`. Bản đồ hết giá trị khi Pixhawk khởi động lại.
- A là hệ RL của tay: **không đổi định nghĩa**, chỉ đổi `T_BA`.
- Đơn vị: Python m; C++ perception mm (`_mm`). Đổi đúng một lần ở ranh giới.
- Tư thế UAV lấy tại thời điểm chụp ảnh / thời điểm điểm LiDAR.

## Nguồn sự thật
- `frames.py` là tham chiếu cho mọi công thức. C++ phải khớp số (`uavp_arm_bridge --selftest` so với `frames.py`). Thêm test khi port công thức mới.
- Hiệu chuẩn nằm trong file yaml (`calib_draft/`, trên Pi `configs/calib/`), có `version`, `date`; đổi thì sao lưu bản cũ, tăng `version`.
- `T_CL` v6: không sửa R, t (z = 42 mm giải ra gộp tâm quang + lệch tầm LD06, khác số thước 12 mm là đúng).

## Không được làm
- Không đổi `R_BC` khi chưa có dữ liệu hiệu chuẩn (K2 hoặc bài chạm vật lệch có hệ thống).
- Không lấy vị trí vật cho tay thẳng từ ảnh (camera không thấy vùng gắp): tay nhận `p_A` từ bản đồ vật + tư thế hiện tại.
- Perception không gửi lệnh bay; chỉ controller.
- Không coi kiểm trên laptop là đã kiểm trên UAV; ghi rõ "chưa chạy trên Pi".
- Không đổi yaw UAV sau khi khoá vật (EKF ngang lệch 5–7 cm khi xoay), trừ khi đo lại vật sau đó.

## Khi xong một việc
Cập nhật bảng "Trạng thái" và "Sai số" trong `README.md`, kèm số đo thật (ngày, lần chạy, độ lệch).
