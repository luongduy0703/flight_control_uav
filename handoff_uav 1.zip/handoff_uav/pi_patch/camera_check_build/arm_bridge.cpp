// uavp_arm_bridge: vi tri vat (he EKF NED cua Pixhawk) -> he tay A -> UDP 5555 cho tracker RL / IK (rl_arm5).
//   ./build/uavp_arm_bridge --cfg configs/run/real_time.yaml --objects ~/objects.json --id 0
//   ./build/uavp_arm_bridge --cfg configs/run/real_time.yaml --target-ekf -0.27 0.17 -0.05
//       [--T-BA configs/calib/T_BA.yaml] [--udp 127.0.0.1:5555] [--hz 30] [--print] [--selftest]
// Moi chu ky: tu the moi nhat cua Pixhawk (shared memory uavp_fc_bridge) -> T_WB(t) (vi tri + z tu EKF, KHONG thay
// z bang rangefinder, cung he voi objects.json do object_map.py ghi) ->
//   p_B = R_WB^T (p_ekf - t_WB),   p_A = R_BA^T (p_B - t_BA)   (= frames.object_in_arm, UAV_FRAMES_PLAN.md muc 3)
// Goi UDP (rl_arm5/determine_depth/core/ipc_bridge.py): struct "!Bffffff?d" = 0xAA, x y z (m, he A), vx vy vz (m/s,
// he A, loc), is_valid, timestamp (s, dong ho he thong). is_valid = false khi tu the cu hon --max-age hoac EKF chua co
// vi tri ngang hoac chua co vat.
// objects.json doc lai moi khi file doi (object_map.py ghi nguyen khoi).
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#include <yaml-cpp/yaml.h>

#include "uavp/common/config.hpp"
#include "uavp/common/log.hpp"
#include "uavp/sources/mavlink.hpp"
#include "uavp/tracking/world_pose.hpp"

using namespace uavp;

namespace {

constexpr const char* kModule = "uavp.arm_bridge";
constexpr double kRadToDeg = 180.0 / CV_PI;
const cv::Vec3d kGraspCentreA(0.0, 0.295, 0.40);  // tam vung gap muc 0 (frames.P_A_STAR)

std::atomic<bool> g_stop{false};
void on_signal(int) { g_stop = true; }

struct Args {
    std::string cfg;
    std::vector<std::string> overrides;
    std::string objects;
    int id{-1};
    std::optional<cv::Vec3d> target_ekf;
    std::string T_BA{"configs/calib/T_BA.yaml"};
    std::string host{"127.0.0.1"};
    int port{5555};
    double hz{30.0};
    double max_age_s{0.3};
    bool print{false};
    bool selftest{false};
};

Args parse_args(int argc, char** argv) {
    Args a;
    for (int i = 1; i < argc; ++i) {
        const auto is = [&](const char* s) { return std::strcmp(argv[i], s) == 0; };
        const bool more = i + 1 < argc;
        if (is("--cfg") && more) a.cfg = argv[++i];
        else if (is("--objects") && more) a.objects = argv[++i];
        else if (is("--id") && more) a.id = std::stoi(argv[++i]);
        else if (is("--target-ekf") && i + 3 < argc) {
            const double n = std::stod(argv[++i]), e = std::stod(argv[++i]), d = std::stod(argv[++i]);
            a.target_ekf = cv::Vec3d(n, e, d);
        } else if (is("--T-BA") && more) a.T_BA = argv[++i];
        else if (is("--udp") && more) {
            const std::string s = argv[++i];
            const auto c = s.rfind(':');
            if (c == std::string::npos) throw std::invalid_argument("--udp host:port");
            a.host = s.substr(0, c);
            a.port = std::stoi(s.substr(c + 1));
        } else if (is("--hz") && more) a.hz = std::stod(argv[++i]);
        else if (is("--max-age") && more) a.max_age_s = std::stod(argv[++i]);
        else if (is("--print")) a.print = true;
        else if (is("--selftest")) a.selftest = true;
        else if (is("--set"))
            while (i + 1 < argc && std::strncmp(argv[i + 1], "--", 2) != 0) a.overrides.emplace_back(argv[++i]);
        else throw std::invalid_argument(std::string("tham so la: ") + argv[i]);
    }
    if (!a.selftest && a.cfg.empty())
        throw std::invalid_argument("Dung: uavp_arm_bridge --cfg configs/run/real_time.yaml (--objects objects.json --id N | "
                                    "--target-ekf N E D) [--T-BA configs/calib/T_BA.yaml] [--udp 127.0.0.1:5555]");
    if (!a.selftest && !a.target_ekf && (a.objects.empty() || a.id < 0))
        throw std::invalid_argument("can --objects + --id, hoac --target-ekf N E D");
    return a;
}

// Tay -> than (calib_draft/T_BA.yaml): p_B = R_BA p_A + t_BA (m).
struct ArmBody {
    cv::Matx33d R_BA{cv::Matx33d::eye()};
    cv::Vec3d t_BA_m{0, 0, 0};
};

ArmBody load_arm_body(const std::string& path) {
    const YAML::Node n = YAML::LoadFile(path);
    ArmBody a;
    for (int r = 0; r < 3; ++r)
        for (int c = 0; c < 3; ++c) a.R_BA(r, c) = n["R_BA"][r][c].as<double>();
    for (int k = 0; k < 3; ++k) a.t_BA_m[k] = n["t_BA_m"][k].as<double>();
    const cv::Matx33d I = a.R_BA.t() * a.R_BA;
    for (int r = 0; r < 3; ++r)
        for (int c = 0; c < 3; ++c)
            if (std::abs(I(r, c) - (r == c ? 1.0 : 0.0)) > 1e-3) throw std::runtime_error(path + ": R_BA khong truc chuan");
    return a;
}

// p_A = R_BA^T (R_WB^T (p_ekf - t_WB) - t_BA)
cv::Vec3d object_in_arm(const cv::Vec3d& p_ekf, double roll, double pitch, double yaw, const cv::Vec3d& t_WB,
                        const ArmBody& arm, cv::Vec3d* p_B_out = nullptr) {
    const cv::Matx33d R_WB = rotation_ned_from_body(roll, pitch, yaw);
    const cv::Vec3d p_B = R_WB.t() * (p_ekf - t_WB);
    if (p_B_out != nullptr) *p_B_out = p_B;
    return arm.R_BA.t() * (p_B - arm.t_BA_m);
}

bool selftest() {
    ArmBody arm;
    arm.R_BA = cv::Matx33d(0, 1, 0, 1, 0, 0, 0, 0, -1);
    arm.t_BA_m = {0.0158, -0.030, 0.6908};
    // Gia tri tham chieu: frames.object_in_arm (Python) cung dau vao.
    const cv::Vec3d p = object_in_arm({1.3, 2.1, 0.0}, 0.05, -0.03, 1.2, {1.0, 2.0, -0.7}, arm);
    const cv::Vec3d ref(-0.17840481, 0.20701723, -0.01412547);
    const bool ok = cv::norm(p - ref) < 1e-6;
    std::printf("arm_bridge selftest: p_A = (%.8f, %.8f, %.8f) | tham chieu frames.py (%.8f, %.8f, %.8f) -> %s\n", p[0],
                p[1], p[2], ref[0], ref[1], ref[2], ok ? "DAT" : "LOI");
    return ok;
}

// --- objects.json (object_map.py): {"objects": [{"id": 0, "p_ekf_m": [n, e, d], ...}]} -------------------------
struct ObjectFile {
    std::string path;
    std::filesystem::file_time_type mtime{};
    std::optional<cv::Vec3d> p;

    bool reload(int id) {  // true neu doc lai
        std::error_code ec;
        const auto t = std::filesystem::last_write_time(path, ec);
        if (ec || (p && t == mtime)) return false;
        mtime = t;
        try {
            const YAML::Node n = YAML::LoadFile(path);  // JSON la tap con cua YAML
            p.reset();
            for (const auto& o : n["objects"])
                if (o["id"].as<int>() == id) {
                    const auto& v = o["p_ekf_m"];
                    p = cv::Vec3d(v[0].as<double>(), v[1].as<double>(), v[2].as<double>());
                }
            if (!p) UAVP_LOG_WARN(kModule, "%s: khong co vat id %d", path.c_str(), id);
        } catch (const std::exception& e) {
            UAVP_LOG_WARN(kModule, "Doc %s loi: %s", path.c_str(), e.what());
        }
        return true;
    }
};

// --- Goi UDP "!Bffffff?d" (big-endian, khong dem) = 34 byte ---------------------------------------------------
void put_f32(std::vector<uint8_t>& b, double v) {
    const float f = static_cast<float>(v);
    uint32_t u = 0;
    std::memcpy(&u, &f, 4);
    u = htonl(u);
    const auto* p = reinterpret_cast<const uint8_t*>(&u);
    b.insert(b.end(), p, p + 4);
}
void put_f64(std::vector<uint8_t>& b, double v) {
    uint64_t u = 0;
    std::memcpy(&u, &v, 8);
    for (int k = 7; k >= 0; --k) b.push_back(static_cast<uint8_t>((u >> (8 * k)) & 0xFFU));
}
std::vector<uint8_t> packet(const cv::Vec3d& p, const cv::Vec3d& v, bool valid) {
    std::vector<uint8_t> b;
    b.reserve(34);
    b.push_back(0xAA);
    for (int k = 0; k < 3; ++k) put_f32(b, valid ? p[k] : 0.0);
    for (int k = 0; k < 3; ++k) put_f32(b, valid ? v[k] : 0.0);
    b.push_back(valid ? 1 : 0);
    const double now = std::chrono::duration<double>(std::chrono::system_clock::now().time_since_epoch()).count();
    put_f64(b, now);
    return b;
}

int run_main(int argc, char** argv) {
    const Args args = parse_args(argc, argv);
    if (args.selftest) return selftest() ? 0 : 1;
    const YAML::Node raw = load_raw(args.cfg, args.overrides);
    const MavlinkConfig mav = mavlink_config(raw["sources"]["mavlink"]);
    auto logger = std::make_unique<Logger>(Level::kInfo);
    set_logger(logger.get());
    std::signal(SIGINT, on_signal);
    std::signal(SIGTERM, on_signal);

    const ArmBody arm = load_arm_body(args.T_BA);
    UAVP_LOG_INFO(kModule, "T_BA %s: t = (%.4f, %.4f, %.4f) m | UDP -> %s:%d, %.0f Hz", args.T_BA.c_str(), arm.t_BA_m[0],
                  arm.t_BA_m[1], arm.t_BA_m[2], args.host.c_str(), args.port, args.hz);
    const std::unique_ptr<IFcSource> fc = open_fc_source(mav);
    UAVP_LOG_INFO(kModule, "Pixhawk: %s", fc->describe().c_str());

    const int sock = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) throw std::runtime_error("khong tao duoc socket UDP");
    sockaddr_in dst{};
    dst.sin_family = AF_INET;
    dst.sin_port = htons(static_cast<uint16_t>(args.port));
    if (::inet_pton(AF_INET, args.host.c_str(), &dst.sin_addr) != 1) throw std::invalid_argument("--udp: host sai");

    ObjectFile obj{args.objects, {}, args.target_ekf};
    if (args.target_ekf)
        UAVP_LOG_INFO(kModule, "Vat (EKF NED) co dinh: (%.3f, %.3f, %.3f) m", (*args.target_ekf)[0],
                      (*args.target_ekf)[1], (*args.target_ekf)[2]);

    const auto period = std::chrono::duration<double>(1.0 / args.hz);
    auto next = std::chrono::steady_clock::now();
    int64_t t_print = 0, t_last = 0;
    cv::Vec3d p_last{0, 0, 0}, vel{0, 0, 0};
    bool have_last = false;
    std::size_t sent = 0, valid_n = 0;
    while (!g_stop) {
        if (!args.target_ekf && obj.reload(args.id) && obj.p)
            UAVP_LOG_INFO(kModule, "Vat id %d (EKF NED): (%.3f, %.3f, %.3f) m", args.id, (*obj.p)[0], (*obj.p)[1],
                          (*obj.p)[2]);
        const int64_t now = mono_ns();
        const int64_t t_att = fc->poses().latest_attitude_ns();
        FcPose pose;
        const bool fresh = t_att > 0 && static_cast<double>(now - t_att) / 1e9 < args.max_age_s &&
                           fc->poses().pose_at(t_att, pose);
        const bool valid = fresh && pose.has_position && obj.p.has_value();
        cv::Vec3d p_A{kNaN, kNaN, kNaN}, p_B{kNaN, kNaN, kNaN};
        if (valid) {
            p_A = object_in_arm(*obj.p, pose.roll_rad, pose.pitch_rad, pose.yaw_rad, pose.pos_ned_m, arm, &p_B);
            if (have_last && t_att > t_last) {
                const double dt = static_cast<double>(t_att - t_last) / 1e9;
                vel = 0.7 * vel + 0.3 * (p_A - p_last) / dt;  // loc thong thap
            }
            if (t_att > t_last) {
                p_last = p_A;
                t_last = t_att;
                have_last = true;
            }
            ++valid_n;
        } else {
            have_last = false;
            vel = {0, 0, 0};
        }
        const auto b = packet(p_A, vel, valid);
        if (::sendto(sock, b.data(), b.size(), 0, reinterpret_cast<const sockaddr*>(&dst), sizeof(dst)) > 0) ++sent;

        if (now - t_print >= (args.print ? kNsPerS / 5 : kNsPerS)) {
            t_print = now;
            if (valid) {
                UAVP_LOG_INFO(kModule, "yaw %.1f | UAV EKF (%.3f, %.3f, %.3f) | vat p_B (%.3f, %.3f, %.3f) | p_A (%.3f, %.3f, "
                              "%.3f) m, cach tam vung gap %.0f mm | gui %zu (%zu hop le)", pose.yaw_rad * kRadToDeg,
                              pose.pos_ned_m[0], pose.pos_ned_m[1], pose.pos_ned_m[2], p_B[0], p_B[1], p_B[2], p_A[0],
                              p_A[1], p_A[2], 1000.0 * cv::norm(p_A - kGraspCentreA), sent, valid_n);
            } else {
                UAVP_LOG_WARN(kModule, "KHONG hop le: %s | gui %zu", !fresh ? "chua co tu the moi (bridge / router?)"
                              : !pose.has_position ? "EKF chua co vi tri ngang" : "chua co vat", sent);
            }
        }
        next += std::chrono::duration_cast<std::chrono::steady_clock::duration>(period);
        std::this_thread::sleep_until(next);
    }
    // bao tay mat vat truoc khi thoat
    const auto b = packet({0, 0, 0}, {0, 0, 0}, false);
    (void)::sendto(sock, b.data(), b.size(), 0, reinterpret_cast<const sockaddr*>(&dst), sizeof(dst));
    ::close(sock);
    UAVP_LOG_INFO(kModule, "Dung: gui %zu goi (%zu hop le)", sent, valid_n);
    set_logger(nullptr);
    return 0;
}

}  // namespace

int main(int argc, char** argv) {
    try {
        return run_main(argc, argv);
    } catch (const std::exception& e) {
        set_logger(nullptr);
        std::cerr << "LOI: " << e.what() << '\n';
        return 1;
    }
}
