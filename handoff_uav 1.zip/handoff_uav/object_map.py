#!/usr/bin/env python3
"""Bản đồ vật trong hệ EKF NED của Pixhawk (UAV_FRAMES_PLAN.md mục 2b, việc #7 của handoff).

Mỗi lần đo một vật (kết quả s4 của perception, hoặc ArUco của camera_check) → gộp với vật cũ cùng nhãn
cách dưới --merge-m (mặc định 0,10 m) → id cố định, trung bình cộng dồn, lưu JSON.

Toạ độ lưu ở hệ EKF (NED, m), KHÔNG lưu ở W: cầu nối tay (uavp_arm_bridge) chỉ cần T_WB(t) của EKF, gốc W
triệt tiêu. W = EKF − origin chỉ để người đọc (có origin trong file nếu biết). Bản đồ hết giá trị khi
Pixhawk khởi động lại (EKF đặt lại gốc).

Ví dụ:
  python3 object_map.py --map objects.json --result ~/uav_perception_pi/runs/*_real_time/result.json
  python3 object_map.py --map objects.json --camera-check runs_pi/20261120-195201_camera_check
  python3 object_map.py --map objects.json --add -0.10 0.08 0.69 hop
  python3 object_map.py --map objects.json --list
  python3 object_map.py --selftest
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
from pathlib import Path

MERGE_M = 0.10


def _finite(v):
    return v is not None and all(isinstance(x, (int, float)) and math.isfinite(x) for x in v)


class ObjectMap:
    def __init__(self, path: Path | None = None, merge_m: float = MERGE_M):
        self.path = path
        self.merge_m = merge_m
        self.objects: list[dict] = []
        self.next_id = 0
        self.origin_ekf_m = None  # gốc W trong hệ EKF (nếu biết), chỉ để in
        if path is not None and path.exists():
            d = json.loads(path.read_text())
            self.objects = d.get("objects", [])
            self.next_id = d.get("next_id", len(self.objects))
            self.origin_ekf_m = d.get("origin_ekf_ned_m")

    def add(self, p_ekf_m, label: str = "", source: str = "", t: float | None = None) -> int:
        """Thêm một lần đo; trả về id vật (cũ nếu gộp được)."""
        p = [float(x) for x in p_ekf_m]
        if not _finite(p):
            raise ValueError(f"toạ độ không hợp lệ: {p_ekf_m}")
        t = time.time() if t is None else t
        best, best_d = None, self.merge_m
        for o in self.objects:
            if label and o["label"] and o["label"] != label:
                continue
            d = math.dist(o["p_ekf_m"], p)
            if d < best_d:
                best, best_d = o, d
        if best is None:
            best = {"id": self.next_id, "label": label, "p_ekf_m": p, "n": 0, "m2": [0.0, 0.0, 0.0],
                    "first_seen": t, "last_seen": t, "sources": []}
            self.objects.append(best)
            self.next_id += 1
        # trung bình cộng dồn (Welford) theo từng trục
        best["n"] += 1
        n = best["n"]
        for k in range(3):
            delta = p[k] - (best["p_ekf_m"][k] if n > 1 else p[k])
            mean = best["p_ekf_m"][k] + delta / n if n > 1 else p[k]
            best["m2"][k] += delta * (p[k] - mean)
            best["p_ekf_m"][k] = mean
        best["last_seen"] = t
        if not best["label"]:
            best["label"] = label
        if source and source not in best["sources"]:
            best["sources"] = (best["sources"] + [source])[-10:]
        return best["id"]

    def get(self, oid: int) -> dict | None:
        return next((o for o in self.objects if o["id"] == oid), None)

    @staticmethod
    def std_m(o) -> list[float]:
        return [math.sqrt(m / (o["n"] - 1)) if o["n"] > 1 else float("nan") for m in o["m2"]]

    def to_w(self, p):
        if self.origin_ekf_m is None:
            return None
        return [p[k] - self.origin_ekf_m[k] for k in range(3)]

    def save(self):
        if self.path is None:
            return
        d = {"frame": "EKF NED (m) cua Pixhawk; W = p_ekf - origin_ekf_ned_m",
             "origin_ekf_ned_m": self.origin_ekf_m, "merge_m": self.merge_m, "next_id": self.next_id,
             "saved": time.time(), "objects": self.objects}
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(d, indent=2))
        tmp.replace(self.path)  # ghi nguyên khối: cầu nối tay đọc không bao giờ thấy file dở

    def table(self) -> str:
        rows = [f"{'id':>3} {'nhan':<12} {'n':>4}  {'N':>7} {'E':>7} {'D':>7} (m EKF)  {'lech chuan mm':>18}  W (m)"]
        for o in self.objects:
            p, s, w = o["p_ekf_m"], self.std_m(o), self.to_w(o["p_ekf_m"])
            sd = " ".join(f"{1000 * x:5.0f}" for x in s)
            ws = "" if w is None else " ".join(f"{x:6.3f}" for x in w)
            rows.append(f"{o['id']:>3} {o['label'][:12]:<12} {o['n']:>4}  {p[0]:7.3f} {p[1]:7.3f} {p[2]:7.3f}"
                        f"           {sd:>18}  {ws}")
        return "\n".join(rows)


# --- nguồn đo -------------------------------------------------------------------------------------------
def from_result_json(path: Path):
    """result.json của uavp_real_time: lock.p_W_mm (s4 cuối, NED EKF mm), không có thì lock.p_W_lock_mm."""
    d = json.loads(path.read_text())
    lock = d.get("lock") or {}
    p = lock.get("p_W_mm") or lock.get("p_W_lock_mm")
    if not _finite(p):
        return None
    sel = d.get("selected") or {}
    label = sel.get("class", "") if isinstance(sel, dict) else ""
    return [x / 1000.0 for x in p], label


def from_camera_check(run_dir: Path):
    """camera_check: mỗi mẫu SPACE (snapshots.csv) có pEKF (mm). Gốc W lấy từ summary.json."""
    out = []
    with open(run_dir / "snapshots.csv") as f:
        for r in csv.DictReader(f):
            try:
                p = [float(r[k]) / 1000.0 for k in ("pEKF_n_mm", "pEKF_e_mm", "pEKF_d_mm")]
            except (KeyError, ValueError):
                continue
            if _finite(p):
                out.append(p)
    origin = None
    s = run_dir / "summary.json"
    if s.exists():
        sj = json.loads(s.read_text())
        if sj.get("origin_set"):
            origin = sj.get("origin_ekf_ned_m")
    return out, origin


def selftest() -> bool:
    m = ObjectMap(None)
    a = m.add([1.00, 2.00, 0.70], "hop")
    b = m.add([1.04, 2.02, 0.70], "hop")       # cách 4,5 cm → gộp
    c = m.add([1.30, 2.00, 0.70], "hop")       # cách 30 cm → vật mới
    d = m.add([1.01, 2.00, 0.70], "tru")       # trùng chỗ nhưng khác nhãn → vật mới
    o = m.get(a)
    ok = (a == b == 0 and c == 1 and d == 2 and o["n"] == 2
          and abs(o["p_ekf_m"][0] - 1.02) < 1e-9 and abs(o["p_ekf_m"][1] - 2.01) < 1e-9)
    s = m.std_m(o)
    ok &= abs(s[0] - math.sqrt(0.0008)) < 1e-9
    print("object_map selftest:", "DAT" if ok else "LOI")
    return ok


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--map", type=Path, default=Path("objects.json"))
    ap.add_argument("--merge-m", type=float, default=MERGE_M)
    ap.add_argument("--result", type=Path, nargs="*", default=[], help="result.json của uavp_real_time")
    ap.add_argument("--camera-check", type=Path, nargs="*", default=[], help="thư mục runs/*_camera_check")
    ap.add_argument("--label", default="", help="nhãn cho --camera-check / --add")
    ap.add_argument("--add", nargs=4, metavar=("N", "E", "D", "NHAN"), help="thêm tay một vật (m, EKF NED)")
    ap.add_argument("--origin", type=float, nargs=3, metavar=("N", "E", "D"), help="đặt gốc W trong hệ EKF (m)")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)

    m = ObjectMap(a.map, a.merge_m)
    if a.origin:
        m.origin_ekf_m = list(a.origin)
    for p in a.result:
        r = from_result_json(p)
        if r is None:
            print(f"bo qua {p}: khong co lock.p_W_mm")
            continue
        oid = m.add(r[0], r[1] or a.label, str(p.parent.name))
        print(f"{p.parent.name}: vat id {oid} ({r[1]})")
    for d in a.camera_check:
        pts, origin = from_camera_check(d)
        if origin is not None and m.origin_ekf_m is None:
            m.origin_ekf_m = origin
        for p in pts:
            oid = m.add(p, a.label or "aruco", d.name)
        print(f"{d.name}: {len(pts)} mau")
    if a.add:
        oid = m.add([float(x) for x in a.add[:3]], a.add[3], "tay")
        print(f"them tay: vat id {oid}")
    m.save()
    if a.list or a.result or a.camera_check or a.add:
        print(m.table())


if __name__ == "__main__":
    main()
