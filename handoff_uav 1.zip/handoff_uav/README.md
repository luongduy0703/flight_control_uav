# Hệ toạ độ chung UAV – camera – LiDAR – tay gắp

Cập nhật 2026-11-21. Gói này chứa mọi thứ về phần toạ độ: code, file hiệu chuẩn, cách chạy trên Pi, kết quả đo và việc còn lại. Mang sang máy khác là làm tiếp được.

**Mục tiêu:** UAV, camera, LiDAR, tay và mọi vật cùng dùng **một hệ thế giới W**. Vật đứng yên thì toạ độ W không đổi, dù UAV nhìn nó từ đâu. UAV bay thì toạ độ của chính nó trong W thay đổi.

## Trạng thái

| Phần | Trạng thái | Bằng chứng |
|---|---|---|
| Hệ W (gốc ở mặt sàn ngay dưới Pixhawk lúc bắt đầu, trục NED của EKF) | ✅ chạy trên Pi | `camera_check` đặt gốc, lấy sàn từ LiDAR |
| Camera → thân (`T_BC` v1) | ✅ kiểm trên giá | độ sâu +1,8 mm so với thước; ngang ±2 cm (sai số thước) |
| LiDAR → camera (`T_CL` v6) | ✅ kiểm trên giá | sàn −1 mm; mặt vật so với ArUco −5 mm |
| Vật đứng yên trong W khi UAV đứng yên / dời ngang / nhấc lên-hạ xuống | ✅ | ≤ 2,4 cm |
| Vật đứng yên trong W khi UAV bị **nghiêng hoặc xoay yaw bằng tay** | ⚠️ 5–7 cm | lỗi vị trí ngang của EKF (optical flow), không phải camera |
| Bản đồ vật (`object_map.py`) | ✅ chạy trên Pi | gộp 6 mẫu, lệch chuẩn ≤ 2 mm |
| Cầu nối sang tay (`uavp_arm_bridge`, UDP 5555) | ✅ chạy trên Pi | gói đúng định dạng rl_arm5; `p_B` khớp `camera_check` ≤ 4 mm |
| Tay → thân (`T_BA`) | ❌ **chưa kiểm** | mới đo thước; chưa có tay |
| Bay thật (V3) | ❌ chưa làm | mọi bài mới làm trên giá kê hoặc cầm tay |
| Lệnh `approach` cho controller | ❌ chưa viết | |

## Thư mục này có gì

| File | Nội dung |
|---|---|
| `README.md` | file này |
| `CLAUDE.md` | quy tắc cho Claude Code / người làm tiếp |
| `frames.py` | thư viện quy đổi toạ độ, bản tham chiếu của mọi công thức. `python3 frames.py --selftest` |
| `object_map.py` | bản đồ vật trong hệ EKF: gộp các lần đo cách nhau < 10 cm, id cố định, ghi `objects.json`. `--selftest` |
| `ik_grasp_loop.py` | vòng gắp IK (dùng tracker của `rl_arm5`), cho bài "chạm vật" khi có tay |
| `calib_draft/T_BC.yaml` | camera → thân, v1 (t đo thước, R danh nghĩa) |
| `calib_draft/T_CL.yaml` | LiDAR → camera, v6 (v5 + `range_offset_m` 0,019) |
| `calib_draft/T_BA.yaml` | tay → thân, v0 (thước, chưa kiểm) |
| `pi_patch/camera_check_build/` | `CMakeLists.txt` + `camera_check.cpp` + `arm_bridge.cpp`: build NGOÀI repo perception trên Pi |
| `pi_patch/his_perception_uav.diff` | cùng thay đổi đó dưới dạng patch cho repo `his_perception_uav` (CMake + `T_CL` v6); 2 file `apps/*.cpp` lấy trong `camera_check_build/` |
| `results/` | 4 lần chạy trên Pi tối 2026-11-20 (CSV, log, summary; ít ảnh) |
| `UAV_FRAMES_PLAN.md` | kế hoạch đầy đủ + nhật ký test (mục 9, 11). Chỉ đọc khi cần chi tiết |
| `aruco_4x4_id0_40mm_A4.pdf` | marker test (in ra cạnh viền đen đo được 36,5 mm) |

## Các hệ toạ độ

Quy ước: `p_X = R_XY·p_Y + t_XY`. Chỉ dùng NED (W) và FRD (B).

| Hệ | Gốc | Trục |
|---|---|---|
| **W** thế giới | mặt sàn ngay dưới Pixhawk **lúc bắt đầu chạy** (`camera_check` giữ yên 2 s đầu) | NED của EKF |
| **EKF** | gốc EKF của Pixhawk (đặt lại khi Pixhawk khởi động) | NED |
| **B** thân | tâm Pixhawk | x = mũi tên Pixhawk = phía camera, y phải, z xuống |
| **C** camera | tâm quang IMX708 | OpenCV trên ảnh đã lật 180°: x phải, y xuống, z nhìn xuống |
| **L** LD06 | tâm quay | x trước, y trái, z lên (mặt quét là một "rèm" trái–phải dưới UAV) |
| **A** tay (RL) | gốc ảo dưới J1 0,5808 m | x phải, y trước (= mũi UAV), z lên. **Không đổi định nghĩa A** (SAC đã train) |

```
đo:    p_W = T_WB(t) · T_BC · p_C          (LiDAR: p_C = T_CL · p_L)
gốc:   W = EKF − o,   o = (x, y của Pixhawk; z của sàn đo bằng LiDAR) lúc bắt đầu
tay:   p_A = T_BA⁻¹ · T_WB(t)⁻¹ · p_EKF    (gốc W triệt tiêu → bản đồ vật lưu ở hệ EKF)
```
z của `T_WB` lấy **từ EKF**, không thay bằng rangefinder (`--set sources.mavlink.use_rangefinder=false`).

Vị trí trong B (m), đo thước: camera (0,130; −0,030; 0,110), J1 (0,005; −0,030; 0,110), MTF-01 (−0,120; −0,030; 0,090), LD06 ≈ (0,091; −0,018; 0,152) (từ `T_CL`), tâm vùng gắp (0,311; −0,030; 0,291).

## Trên Pi đã có sẵn (`piros2@192.168.50.1`, Pi 4)

| Thứ | Ở đâu | Ghi chú |
|---|---|---|
| Repo perception (bản làm việc của chủ repo, không phải git) | `~/uav_perception_pi` | `CMakeLists.txt` của nó đang hỏng (thiếu 3 file lidar_spread / lidar_check của chủ repo) → **không cmake lại trong đó**; binary cũ vẫn chạy (`build/uavp_fc_check`, `uavp_sensor_check`...) |
| `T_BC` v1 | `~/uav_perception_pi/configs/calib/T_BC.yaml` | bản cũ: `T_BC_v0.yaml` |
| `T_CL` v6 | `~/uav_perception_pi/configs/calib/T_CL.yaml` | chỉ đổi dòng `range_offset_m: 0.019`; bản cũ: `T_CL_v5.yaml` |
| Build riêng của mình | `~/uav_camera_check/` | `CMakeLists.txt`, `camera_check.cpp`, `arm_bridge.cpp`, `object_map.py`, `T_BA.yaml`; binary trong `build/`: `uavp_camera_check`, `uavp_arm_bridge` |
| Bản đồ vật | `~/objects.json` | vật id 0 (hộp ArUco) của phiên cuối; hết giá trị khi Pixhawk khởi động lại |
| Dịch vụ `uavp-fc-bridge` (systemd) | tự chạy | nghe UDP 127.0.0.1:14551 (router) → shared memory `/uavp_fc`; mọi chương trình đọc tư thế từ đây |
| Router + controller | `~/uav/controller` | `tools/run_hardware_router.sh <IP laptop> /dev/ttyAMA0` (TELEM1 921600) |
| Tham số PX4 đã đặt | Pixhawk | `EKF2_OF_POS_*` = `EKF2_RNG_POS_*` = (−0,12; −0,03; 0,09); `SENS_BOARD_ROT` = 0; **Level Horizon** đã làm 2026-11-20 |
| Chưa có | | code tay `rl_arm5` (`~/quan/...`) chưa chép lên Pi này |

Cổng đang dùng: 14540 (controller MAVSDK), 14550 (QGC trên laptop), 14551 (uavp_fc_bridge), 14560 (drift viewer trên laptop), 5555 (vị trí vật → tay), TCP 8100 (viewer ảnh). Không dùng lại.

## Cách chạy

Ký hiệu: **[Laptop]**, **[Pi-1]**, **[Pi-2]**... là các terminal (SSH vào Pi). Laptop phải cùng mạng 192.168.50.x.

### 0. Đưa code lên Pi (khi sửa code trên máy khác)
```bash
# [Laptop], trong thư mục này
scp pi_patch/camera_check_build/{CMakeLists.txt,camera_check.cpp,arm_bridge.cpp} object_map.py calib_draft/T_BA.yaml \
    piros2@192.168.50.1:~/uav_camera_check/
# [Pi-1]
cmake -S ~/uav_camera_check -B ~/uav_camera_check/build && cmake --build ~/uav_camera_check/build -j2
~/uav_camera_check/build/uavp_arm_bridge --selftest      # phải in DAT
```
`T_CL` v6 trên Pi đã có; nếu Pi mất bản này: `sed -i 's/^  range_offset_m: 0.0.*/  range_offset_m: 0.019/' ~/uav_perception_pi/configs/calib/T_CL.yaml`.

### 1. Bật hệ thống (mỗi buổi)
```bash
# [Pi-2] router, để chạy suốt buổi. IP laptop: `hostname -I` trên laptop (card cùng mạng 192.168.50.x)
cd ~/uav/controller && bash tools/run_hardware_router.sh <IP laptop> /dev/ttyAMA0
# [Pi-1] kiểm
journalctl -u uavp-fc-bridge -n 2 --no-pager                       # phải có ATTITUDE ~100/s
ps -ef | grep -E "console.py|uavp_real_time" | grep -v grep        # phải KHÔNG in gì (camera + cổng 8100 rảnh)
```
Router đã có người bật thì dùng chung, không bật cái thứ hai (`sudo fuser -v /dev/ttyAMA0` chỉ thấy 1 `mavlink-routerd`).

### 2. Đo vật bằng camera + LiDAR (`camera_check`)
```bash
# [Pi-1]
cd ~/uav_perception_pi
~/uav_camera_check/build/uavp_camera_check --cfg configs/run/real_time.yaml \
    --set sources.mavlink.use_rangefinder=false aruco.side_mm=36.5
# [Laptop] viewer (trong repo his_perception_uav)
python3 tools/remote_viewer.py --host 192.168.50.1 --port 8100
```
- Giữ UAV yên 2 s đầu (dòng đỏ "DANG DAT GOC W" biến mất; log có `GOC W: ... (LiDAR)`).
- Viewer: SPACE = lưu mẫu, q = thoát. Tham số thêm: `--no-lidar`, `--fc-height-m 0.71` (khi không có LiDAR), `--seconds N`, `--origin-s 2`.
- Màn hình (từ dưới lên): tư thế + UAV trong W; ArUco `p_C`, `p_B`; **VAT trong W**; "theo mũi lúc đặt gốc" (trước / phải / cao trên sàn); dòng LiDAR (sàn, mặt vật, lệch ArUco).
- Kết quả `runs/<giờ>_camera_check/`: `aruco_track.csv`, `lidar_track.csv`, `snapshots.csv`, `summary.json`, `run.log`, `snap_NNN.jpg`.
- ArUco đặt **cạnh** đường LiDAR (đường chấm cam), không đè lên: ô đen/trắng làm LD06 đo lệch.

### 3. Ghi vật vào bản đồ
```bash
# [Pi-1]
python3 ~/uav_camera_check/object_map.py --map ~/objects.json --camera-check $(ls -d runs/*_camera_check | tail -1) --label hop
python3 ~/uav_camera_check/object_map.py --map ~/objects.json --list
# kết quả perception thật (s4): ... --result runs/<giờ>_real_time/result.json
```

### 4. Cầu nối sang tay
```bash
# [Pi-1]
~/uav_camera_check/build/uavp_arm_bridge --cfg configs/run/real_time.yaml --objects ~/objects.json --id 0 \
    --T-BA ~/uav_camera_check/T_BA.yaml          # hoặc --target-ekf N E D; --udp host:port; --hz 30
# [Pi-3] thay cho tay: nghe gói (cột cuối True = hợp lệ)
python3 -c "
import socket,struct;s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.bind(('127.0.0.1',5555))
while 1: print(struct.unpack('!Bffffff?d',s.recv(64))[1:8])"
```
Gói: `struct "!Bffffff?d"` = 0xAA, x y z (m, hệ A), vx vy vz (m/s, lọc), is_valid, timestamp. `is_valid=False` khi tư thế cũ > 0,3 s, EKF chưa có vị trí, hoặc chưa có vật. Log mỗi giây: `p_B`, `p_A`, khoảng cách tới tâm vùng gắp.

### 5. Kiểm nhanh 3 nguồn (không cần ArUco)
```bash
./build/uavp_sensor_check --cfg configs/run/real_time.yaml --seconds 10 --set sources.mavlink.use_rangefinder=false
```

### 6. Tải kết quả về máy
```bash
mkdir -p <thư mục>/runs_pi        # PHẢI tạo trước, không thì scp đổ các lần chạy vào chung 1 chỗ
scp -r piros2@192.168.50.1:'~/uav_perception_pi/runs/*_camera_check' <thư mục>/runs_pi/
```

## Sai số đã đo (trên giá, 2026-11-20, sau Level Horizon)

| Đại lượng | Kết quả |
|---|---|
| Độ sâu camera (ArUco 36,5 mm, 0,54 m) | +1,8 mm so với thước; reproj trung vị 0,06–0,09 px |
| LiDAR mặt vật − ArUco (v6) | −4,6 / −5,1 mm (tứ phân vị −9..−2); sàn 600 (thước 601) |
| Vật trong W, UAV đứng yên 200 s | lệch chuẩn 2,0 / 1,6 / 4,6 mm (x/y/z); trôi 4 mm |
| Dời ngang 27–45 cm | lệch 9–24 mm |
| Nhấc / hạ UAV 19 cm | z vật ±16 mm; độ cao vật trên sàn +2 ± 9,5 mm |
| Cầm tay có nghiêng / xoay yaw ±30° | lệch 50–70 mm, **không tự hồi** (EKF ngang sai; camera vẫn đúng) |
| Khung giá che MTF-01 | z EKF nhảy 30–60 cm, x/y nhảy tới 40 cm → bỏ cả lần chạy |

Số liệu gốc: `results/`. Phân tích từng lần: `UAV_FRAMES_PLAN.md` mục 9 (log) và 11.

## Việc còn lại

1. **Có tay:** bài "chạm vật" (kiểm cả 3 cùng lúc): kê vật trên khối ~20 cm, đo bằng `camera_check` → `object_map` → dời UAV cho `p_B` x ≈ 0,25–0,31 → `uavp_arm_bridge` + `ik_grasp_loop.py` (thử `--mock` trước). Đạt khi đầu ngàm cách tâm ArUco ≤ 2 cm. Kiểm riêng `T_BA`: marker trên ngàm, 4–5 tư thế, so camera với FK + `T_BA` (K4).
2. **Bay:** V3 hover trên vật, vật trong W lệch ≤ 3–5 cm. Xem EKF khi bay có còn lệch kiểu cầm tay không.
3. **Controller:** lệnh `approach` (N, E, D, yaw từ `frames.uav_setpoint`), dung sai 2–3 cm; quy tắc **không đổi yaw sau khi khoá vật**; đo lại vật khi còn trong ảnh để giảm phụ thuộc EKF.
4. **Repo perception (chủ repo):** đưa `camera_check` / `arm_bridge` / `T_CL` v6 vào repo (`pi_patch/his_perception_uav.diff`); sửa `camera_pose()` (z rangefinder thiếu offset, đang tránh bằng `use_rangefinder=false`); `distance.camera_offset_m` = −0,02; sửa CMake thiếu file lidar.
5. Hiệu chuẩn `R_BC` (K2) nếu bài chạm vật lệch theo hướng.

## Sự cố hay gặp

| Triệu chứng | Nguyên nhân / cách xử lý |
|---|---|
| `fc_check` / bridge 0 byte | router chưa bật, hoặc Pixhawk mất điện / dây TELEM1 |
| `remote: khong mo duoc cong TCP 8100` | đang có `uavp_real_time` (con của `console.py`) giữ camera + cổng → chờ / nhờ người đó tắt; không kill `console.py` của người khác |
| Dòng đỏ đặt gốc không tắt | thiếu nguồn độ cao: LiDAR không chạy và `use_rangefinder=false` → thêm `--fc-height-m` |
| z "UAV trong W" nhảy lên ~−200 | MTF-01 bị che (tay, thước, khung giá) → làm lại |
| Lệnh nghe UDP không in gì | `uavp_arm_bridge` chưa chạy, hoặc chạy lệnh nghe trên laptop (phải trên Pi) |
